def strings():
    s1="heruntergeladen."
    s2="Geben Sie den Namen des Colleges ein"
    s3="Vorlagendatei hochladen"
    s4="erstellt"
    s5="Beispiel"
    s6 ="StudentWebsite.txt hochladen"
    s7="Zip-Datei generieren"
    return (s1,s2,s3,s4,s5,s6,s7)
    