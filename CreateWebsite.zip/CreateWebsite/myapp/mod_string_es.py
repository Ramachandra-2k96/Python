def strings():
    s1=" descargado."
    s2="Introduzca el nombre de la universidad"
    s3="Subir archivo de plantilla"
    s4="creado"
    s5="Muestra"
    s6 = "Cargar StudentWebsite.txt "
    s7="Generar Zip"
    return (s1,s2,s3,s4,s5,s6,s7)