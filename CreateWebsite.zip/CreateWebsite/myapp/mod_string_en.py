def strings():
    s1=" downloaded."
    s2="Enter College name"
    s3="Upload Template file"
    s4="created"
    s5="Sample"
    s6 ="Upload StudentWebsite.txt "
    s7 ="Generate Zip"
    return (s1,s2,s3,s4,s5,s6,s7)